﻿namespace Insight_Technologies_Coding_Challenge_GUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.dataChart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.panel1 = new System.Windows.Forms.Panel();
            this.customersGB = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.numOfCustomersNUD = new System.Windows.Forms.NumericUpDown();
            this.customersAddRB = new System.Windows.Forms.RadioButton();
            this.customersSubtractRB = new System.Windows.Forms.RadioButton();
            this.customerChangeByOneThousandBTN = new System.Windows.Forms.Button();
            this.customerChangeByOneHundredBTN = new System.Windows.Forms.Button();
            this.customerChangeByTenBTN = new System.Windows.Forms.Button();
            this.suppliersGB = new System.Windows.Forms.GroupBox();
            this.supplierChangeByOneThousandBTN = new System.Windows.Forms.Button();
            this.supplierChangeByOneHundredBTN = new System.Windows.Forms.Button();
            this.supplierChangeByTenBTN = new System.Windows.Forms.Button();
            this.numOfSuppliersNUD = new System.Windows.Forms.NumericUpDown();
            this.suppliersAddRB = new System.Windows.Forms.RadioButton();
            this.suppliersSubtractRB = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.minLBL = new System.Windows.Forms.Label();
            this.maxNUD = new System.Windows.Forms.NumericUpDown();
            this.minNUD = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.displayGB = new System.Windows.Forms.GroupBox();
            this.panel2 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.dataChart)).BeginInit();
            this.panel1.SuspendLayout();
            this.customersGB.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numOfCustomersNUD)).BeginInit();
            this.suppliersGB.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numOfSuppliersNUD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.maxNUD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.minNUD)).BeginInit();
            this.displayGB.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataChart
            // 
            chartArea2.AxisX.Maximum = 500D;
            chartArea2.AxisX.Minimum = 0D;
            chartArea2.AxisY.Maximum = 500D;
            chartArea2.AxisY.Minimum = 0D;
            chartArea2.Name = "ChartArea1";
            this.dataChart.ChartAreas.Add(chartArea2);
            legend2.Name = "Supply And Demand";
            legend2.Title = "Supply And Demand";
            this.dataChart.Legends.Add(legend2);
            this.dataChart.Location = new System.Drawing.Point(88, 19);
            this.dataChart.Name = "dataChart";
            this.dataChart.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Pastel;
            this.dataChart.Size = new System.Drawing.Size(612, 385);
            this.dataChart.TabIndex = 0;
            this.dataChart.Text = "Supply an Demand";
            this.dataChart.Click += new System.EventHandler(this.dataChart_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.MediumSpringGreen;
            this.panel1.Controls.Add(this.customersGB);
            this.panel1.Controls.Add(this.suppliersGB);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.minLBL);
            this.panel1.Controls.Add(this.maxNUD);
            this.panel1.Controls.Add(this.minNUD);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Location = new System.Drawing.Point(12, 126);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(256, 419);
            this.panel1.TabIndex = 1;

            // 
            // customersGB
            // 
            this.customersGB.Controls.Add(this.label2);
            this.customersGB.Controls.Add(this.numOfCustomersNUD);
            this.customersGB.Controls.Add(this.customersAddRB);
            this.customersGB.Controls.Add(this.customersSubtractRB);
            this.customersGB.Controls.Add(this.customerChangeByOneThousandBTN);
            this.customersGB.Controls.Add(this.customerChangeByOneHundredBTN);
            this.customersGB.Controls.Add(this.customerChangeByTenBTN);
            this.customersGB.Location = new System.Drawing.Point(3, 163);
            this.customersGB.Name = "customersGB";
            this.customersGB.Size = new System.Drawing.Size(253, 153);
            this.customersGB.TabIndex = 1;
            this.customersGB.TabStop = false;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Rockwell", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(49, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(163, 51);
            this.label2.TabIndex = 3;
            this.label2.Text = "Number Of Cusotmers";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // numOfCustomersNUD
            // 
            this.numOfCustomersNUD.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.numOfCustomersNUD.Font = new System.Drawing.Font("Rockwell", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numOfCustomersNUD.Location = new System.Drawing.Point(93, 70);
            this.numOfCustomersNUD.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.numOfCustomersNUD.Name = "numOfCustomersNUD";
            this.numOfCustomersNUD.Size = new System.Drawing.Size(64, 28);
            this.numOfCustomersNUD.TabIndex = 7;
            this.numOfCustomersNUD.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numOfCustomersNUD.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.numOfCustomersNUD.ValueChanged += new System.EventHandler(this.numOfCustomersNUD_ValueChanged);
            // 
            // customersAddRB
            // 
            this.customersAddRB.AutoSize = true;
            this.customersAddRB.Location = new System.Drawing.Point(179, 70);
            this.customersAddRB.Name = "customersAddRB";
            this.customersAddRB.Size = new System.Drawing.Size(44, 17);
            this.customersAddRB.TabIndex = 14;
            this.customersAddRB.TabStop = true;
            this.customersAddRB.Text = "Add";
            this.customersAddRB.UseVisualStyleBackColor = true;
            this.customersAddRB.CheckedChanged += new System.EventHandler(this.customersAddRB_CheckedChanged);
            // 
            // customersSubtractRB
            // 
            this.customersSubtractRB.AutoSize = true;
            this.customersSubtractRB.Location = new System.Drawing.Point(179, 93);
            this.customersSubtractRB.Name = "customersSubtractRB";
            this.customersSubtractRB.Size = new System.Drawing.Size(65, 17);
            this.customersSubtractRB.TabIndex = 15;
            this.customersSubtractRB.TabStop = true;
            this.customersSubtractRB.Text = "Subtract";
            this.customersSubtractRB.UseVisualStyleBackColor = true;
            this.customersSubtractRB.CheckedChanged += new System.EventHandler(this.customersSubtractRB_CheckedChanged);
            // 
            // customerChangeByOneThousandBTN
            // 
            this.customerChangeByOneThousandBTN.Location = new System.Drawing.Point(179, 116);
            this.customerChangeByOneThousandBTN.Name = "customerChangeByOneThousandBTN";
            this.customerChangeByOneThousandBTN.Size = new System.Drawing.Size(60, 30);
            this.customerChangeByOneThousandBTN.TabIndex = 10;
            this.customerChangeByOneThousandBTN.Text = "+ 1000";
            this.customerChangeByOneThousandBTN.UseVisualStyleBackColor = true;
            this.customerChangeByOneThousandBTN.Click += new System.EventHandler(this.customerChangeByOneThousandBTN_Click);
            // 
            // customerChangeByOneHundredBTN
            // 
            this.customerChangeByOneHundredBTN.Location = new System.Drawing.Point(93, 117);
            this.customerChangeByOneHundredBTN.Name = "customerChangeByOneHundredBTN";
            this.customerChangeByOneHundredBTN.Size = new System.Drawing.Size(60, 30);
            this.customerChangeByOneHundredBTN.TabIndex = 9;
            this.customerChangeByOneHundredBTN.Text = "+ 100";
            this.customerChangeByOneHundredBTN.UseVisualStyleBackColor = true;
            this.customerChangeByOneHundredBTN.Click += new System.EventHandler(this.customerChangeByOneHundredBTN_Click);
            // 
            // customerChangeByTenBTN
            // 
            this.customerChangeByTenBTN.Location = new System.Drawing.Point(6, 117);
            this.customerChangeByTenBTN.Name = "customerChangeByTenBTN";
            this.customerChangeByTenBTN.Size = new System.Drawing.Size(60, 30);
            this.customerChangeByTenBTN.TabIndex = 8;
            this.customerChangeByTenBTN.Text = "+ 10";
            this.customerChangeByTenBTN.UseVisualStyleBackColor = true;
            this.customerChangeByTenBTN.Click += new System.EventHandler(this.customerChangeByTenBTN_Click);
            // 
            // suppliersGB
            // 
            this.suppliersGB.BackColor = System.Drawing.Color.MediumSpringGreen;
            this.suppliersGB.Controls.Add(this.supplierChangeByOneThousandBTN);
            this.suppliersGB.Controls.Add(this.supplierChangeByOneHundredBTN);
            this.suppliersGB.Controls.Add(this.supplierChangeByTenBTN);
            this.suppliersGB.Controls.Add(this.numOfSuppliersNUD);
            this.suppliersGB.Controls.Add(this.suppliersAddRB);
            this.suppliersGB.Controls.Add(this.suppliersSubtractRB);
            this.suppliersGB.Controls.Add(this.label1);
            this.suppliersGB.Location = new System.Drawing.Point(3, 4);
            this.suppliersGB.Name = "suppliersGB";
            this.suppliersGB.Size = new System.Drawing.Size(253, 159);
            this.suppliersGB.TabIndex = 21;
            this.suppliersGB.TabStop = false;
            // 
            // supplierChangeByOneThousandBTN
            // 
            this.supplierChangeByOneThousandBTN.Location = new System.Drawing.Point(173, 123);
            this.supplierChangeByOneThousandBTN.Name = "supplierChangeByOneThousandBTN";
            this.supplierChangeByOneThousandBTN.Size = new System.Drawing.Size(60, 30);
            this.supplierChangeByOneThousandBTN.TabIndex = 6;
            this.supplierChangeByOneThousandBTN.Text = "+ 1000";
            this.supplierChangeByOneThousandBTN.UseVisualStyleBackColor = true;
            this.supplierChangeByOneThousandBTN.Click += new System.EventHandler(this.supplierChangeByOneThousandBTN_Click);
            // 
            // supplierChangeByOneHundredBTN
            // 
            this.supplierChangeByOneHundredBTN.Location = new System.Drawing.Point(88, 123);
            this.supplierChangeByOneHundredBTN.Name = "supplierChangeByOneHundredBTN";
            this.supplierChangeByOneHundredBTN.Size = new System.Drawing.Size(60, 30);
            this.supplierChangeByOneHundredBTN.TabIndex = 5;
            this.supplierChangeByOneHundredBTN.Text = "+ 100";
            this.supplierChangeByOneHundredBTN.UseVisualStyleBackColor = true;
            this.supplierChangeByOneHundredBTN.Click += new System.EventHandler(this.supplierChangeByOneHundredBTN_Click);
            // 
            // supplierChangeByTenBTN
            // 
            this.supplierChangeByTenBTN.Location = new System.Drawing.Point(6, 123);
            this.supplierChangeByTenBTN.Name = "supplierChangeByTenBTN";
            this.supplierChangeByTenBTN.Size = new System.Drawing.Size(60, 30);
            this.supplierChangeByTenBTN.TabIndex = 4;
            this.supplierChangeByTenBTN.Text = "+ 10";
            this.supplierChangeByTenBTN.UseVisualStyleBackColor = true;
            this.supplierChangeByTenBTN.Click += new System.EventHandler(this.supplierChangeByTenBTN_Click);
            // 
            // numOfSuppliersNUD
            // 
            this.numOfSuppliersNUD.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.numOfSuppliersNUD.Font = new System.Drawing.Font("Rockwell", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numOfSuppliersNUD.Location = new System.Drawing.Point(84, 76);
            this.numOfSuppliersNUD.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.numOfSuppliersNUD.Name = "numOfSuppliersNUD";
            this.numOfSuppliersNUD.Size = new System.Drawing.Size(64, 28);
            this.numOfSuppliersNUD.TabIndex = 0;
            this.numOfSuppliersNUD.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numOfSuppliersNUD.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.numOfSuppliersNUD.ValueChanged += new System.EventHandler(this.numOfSuppliersNUD_ValueChanged);
            // 
            // suppliersAddRB
            // 
            this.suppliersAddRB.AutoSize = true;
            this.suppliersAddRB.Location = new System.Drawing.Point(168, 64);
            this.suppliersAddRB.Name = "suppliersAddRB";
            this.suppliersAddRB.Size = new System.Drawing.Size(44, 17);
            this.suppliersAddRB.TabIndex = 12;
            this.suppliersAddRB.TabStop = true;
            this.suppliersAddRB.Text = "Add";
            this.suppliersAddRB.UseVisualStyleBackColor = true;
            this.suppliersAddRB.CheckedChanged += new System.EventHandler(this.suppliersAddRB_CheckedChanged);
            // 
            // suppliersSubtractRB
            // 
            this.suppliersSubtractRB.AutoSize = true;
            this.suppliersSubtractRB.Location = new System.Drawing.Point(168, 87);
            this.suppliersSubtractRB.Name = "suppliersSubtractRB";
            this.suppliersSubtractRB.Size = new System.Drawing.Size(65, 17);
            this.suppliersSubtractRB.TabIndex = 13;
            this.suppliersSubtractRB.TabStop = true;
            this.suppliersSubtractRB.Text = "Subtract";
            this.suppliersSubtractRB.UseVisualStyleBackColor = true;
            this.suppliersSubtractRB.CheckedChanged += new System.EventHandler(this.suppliersSubtractRB_CheckedChanged);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Rockwell", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(46, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(163, 51);
            this.label1.TabIndex = 1;
            this.label1.Text = "Number Of Suppliers";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(159, 343);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(38, 20);
            this.label5.TabIndex = 20;
            this.label5.Text = "Max";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(105, 345);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(27, 20);
            this.label4.TabIndex = 19;
            this.label4.Text = "To";
            // 
            // minLBL
            // 
            this.minLBL.AutoSize = true;
            this.minLBL.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.minLBL.Location = new System.Drawing.Point(21, 343);
            this.minLBL.Name = "minLBL";
            this.minLBL.Size = new System.Drawing.Size(34, 20);
            this.minLBL.TabIndex = 18;
            this.minLBL.Text = "Min";
            // 
            // maxNUD
            // 
            this.maxNUD.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.maxNUD.Font = new System.Drawing.Font("Rockwell", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maxNUD.Location = new System.Drawing.Point(154, 366);
            this.maxNUD.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.maxNUD.Name = "maxNUD";
            this.maxNUD.Size = new System.Drawing.Size(79, 28);
            this.maxNUD.TabIndex = 16;
            this.maxNUD.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.maxNUD.ValueChanged += new System.EventHandler(this.maxNUD_ValueChanged);
            this.maxNUD.Enter += new System.EventHandler(this.maxNUD_Enter);
            this.maxNUD.Leave += new System.EventHandler(this.maxNUD_Leave);
            // 
            // minNUD
            // 
            this.minNUD.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.minNUD.Font = new System.Drawing.Font("Rockwell", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.minNUD.Location = new System.Drawing.Point(3, 366);
            this.minNUD.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.minNUD.Minimum = new decimal(new int[] {
            1000000,
            0,
            0,
            -2147483648});
            this.minNUD.Name = "minNUD";
            this.minNUD.Size = new System.Drawing.Size(79, 28);
            this.minNUD.TabIndex = 17;
            this.minNUD.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.minNUD.ValueChanged += new System.EventHandler(this.minNUD_ValueChanged);
            this.minNUD.Enter += new System.EventHandler(this.minNUD_Enter);
            this.minNUD.Leave += new System.EventHandler(this.minNUD_Leave);
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Rockwell", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(49, 312);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(146, 33);
            this.label3.TabIndex = 11;
            this.label3.Text = "Data Range";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // displayGB
            // 
            this.displayGB.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.displayGB.Controls.Add(this.dataChart);
            this.displayGB.Location = new System.Drawing.Point(274, 126);
            this.displayGB.Name = "displayGB";
            this.displayGB.Size = new System.Drawing.Size(734, 419);
            this.displayGB.TabIndex = 2;
            this.displayGB.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel2.BackgroundImage")));
            this.panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panel2.Location = new System.Drawing.Point(12, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1012, 108);
            this.panel2.TabIndex = 3;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1020, 557);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.displayGB);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);

            ((System.ComponentModel.ISupportInitialize)(this.dataChart)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.customersGB.ResumeLayout(false);
            this.customersGB.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numOfCustomersNUD)).EndInit();
            this.suppliersGB.ResumeLayout(false);
            this.suppliersGB.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numOfSuppliersNUD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.maxNUD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.minNUD)).EndInit();
            this.displayGB.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataVisualization.Charting.Chart dataChart;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox displayGB;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.NumericUpDown numOfSuppliersNUD;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label minLBL;
        private System.Windows.Forms.NumericUpDown minNUD;
        private System.Windows.Forms.NumericUpDown maxNUD;
        private System.Windows.Forms.RadioButton customersSubtractRB;
        private System.Windows.Forms.RadioButton customersAddRB;
        private System.Windows.Forms.RadioButton suppliersSubtractRB;
        private System.Windows.Forms.RadioButton suppliersAddRB;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button customerChangeByOneThousandBTN;
        private System.Windows.Forms.Button customerChangeByOneHundredBTN;
        private System.Windows.Forms.Button customerChangeByTenBTN;
        private System.Windows.Forms.NumericUpDown numOfCustomersNUD;
        private System.Windows.Forms.Button supplierChangeByOneThousandBTN;
        private System.Windows.Forms.Button supplierChangeByOneHundredBTN;
        private System.Windows.Forms.Button supplierChangeByTenBTN;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox customersGB;
        private System.Windows.Forms.GroupBox suppliersGB;
    }
}

