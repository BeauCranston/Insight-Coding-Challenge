﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.Windows.Forms.DataVisualization.Charting;
namespace Insight_Technologies_Coding_Challenge_GUI
{
    /// <summary>
    /// I was unfortunately not able to completely solve this problem. I had no experience with using WinForms Charts and i found them to be extremely unreliable and hard to use but i did my very best to put 
    /// together what was expected of me. Hopefully my logic makes enough sense that you can see what i was trying to do and find it in your kind hearts to still consider me
    /// </summary>
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public int max;
        public int min;
        public int customerCount;
        public int supplierCount;

        
        public Series customers = new Series();
        public Series suppliers = new Series();
        public List<Series> connectionList = new List<Series>();


        /// <summary>
        /// I tried everything i possibly could to make the relationship between supplier and customer that work. After hours and hours of trying i found the best results were when i made the 
        /// customers and suppliers into a list of chart series, and then had one point per series. That way i could connect one point to one line 
        /// </summary>
       // public List<Series> supplierList = new List<Series>();
        //public List<Series> customerList = new List<Series>();
        private void Form1_Load(object sender, EventArgs e)
        {
            minNUD.Value = 0;
            maxNUD.Value = 500;
            min = (int)minNUD.Value;
            max = (int)maxNUD.Value;
            numOfSuppliersNUD.Value = 5;
            numOfCustomersNUD.Value = 100;
            customerCount = (int)numOfCustomersNUD.Value;
            supplierCount = (int)numOfSuppliersNUD.Value;
            customersAddRB.Checked = true;
            suppliersAddRB.Checked = true;
            
            dataChart.ChartAreas.FindByName("ChartArea1").Visible = true;
            customers.ChartType = SeriesChartType.Point;
            suppliers.ChartType = SeriesChartType.Point;
            AddSuppliers(suppliers, supplierCount);
            AddCustomers(customers, customerCount);
            GenerateConnections();
            
        }


        public void AddSuppliers(Series series, int numOfPoints)
        {
            if(numOfPoints > 0)
            {
                DataPoint[] suppliers = new DataPoint[numOfPoints];
                Random rand = new Random();
                for (int i = 0; i < numOfPoints; i++)
                {
                    suppliers[i] = new DataPoint(rand.Next(min, max), rand.Next(min, max));
                    suppliers[i].MarkerColor = Color.FromArgb(rand.Next(1, 255), rand.Next(1, 255), rand.Next(1, 255));
                    suppliers[i].MarkerStyle = MarkerStyle.Circle;
                    suppliers[i].MarkerSize = 10;
                    series.Points.Add(suppliers[i]);
                }
                GenerateConnections();
            }

            else if (numOfPoints < 0)
            {
                if (numOfSuppliersNUD.Value != 0)
                {
                    for (int i = 0; i < Math.Abs(numOfPoints); i++)
                    {
                        series.Points.Remove(series.Points.Last());
                        
                        
                    }

                    GenerateConnections();
                    
                }

                else
                {
                    
                    Debug.WriteLine("No more suppliers");
                }

            }


        }

        public void AddCustomers(Series series, int numOfPoints)
        {
            if(numOfPoints > 0)
            {
                DataPoint[] customers = new DataPoint[numOfPoints];
                Random rand = new Random();
                for (int i = 0; i < numOfPoints; i++)
                {
                    customers[i] = new DataPoint(rand.Next(min, max), rand.Next(min, max));
                    customers[i].IsVisibleInLegend = false;
                    customers[i].MarkerColor = Color.Black;
                    customers[i].MarkerStyle = MarkerStyle.Circle;
                    customers[i].MarkerSize = 5;
                    series.Points.Add(customers[i]);
                    ConnectToClosestSupplier(customers[i]);

                }

            }

            else if(numOfPoints < 0)
            {
                if (numOfCustomersNUD.Value != 0)
                {
                    for (int i = 0; i < Math.Abs(numOfPoints); i++)
                    {
                        series.Points.Remove(series.Points.Last());
                    }
                    GenerateConnections();
                }

                else
                {
                    Debug.WriteLine("No more customers");
                }
            }


        }


        Func<DataPoint, DataPoint, double> VectorMagnitude = (DataPoint customer, DataPoint supplyer) =>
        {
            double x = customer.XValue - supplyer.XValue;
            double y = customer.YValues[0] - supplyer.YValues[0];


            return Math.Sqrt(Math.Pow(x, 2) + Math.Pow(y, 2));
        };

        public void GenerateConnections()
        {
            dataChart.Series.Clear();
            dataChart.Series.Add(customers);
            dataChart.Series.Add(suppliers);
            foreach ( DataPoint customer in customers.Points)
            {
                ConnectToClosestSupplier(customer);
            }



        }

        public void ConnectToClosestSupplier(DataPoint customer)
        {
            double temp = max * 2;
            DataPoint closestSupplier = null;
            foreach (DataPoint supplier in suppliers.Points)
            {

                double smallest = Math.Abs(VectorMagnitude(customer, supplier));



                if (smallest < temp)
                {
                    temp = smallest;
                    closestSupplier = supplier;

                }

            }
            Series connection = new Series();
            connection.ChartType = SeriesChartType.Line;
            connection.IsVisibleInLegend = false;
            connection.Color = closestSupplier.MarkerColor;
            dataChart.Series.Add(connection);
            connectionList.Add(connection);
            connection.Points.Add(customer);
            connection.Points.Add(closestSupplier);
        }
        private void dataChart_Click(object sender, EventArgs e)
        {

        }


        /// <summary>
        /// when the numeric up down changes on the suppliers add the new suppliers and re generate the connections.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void numOfSuppliersNUD_ValueChanged(object sender, EventArgs e)
        {
            int numberToAdd = (int)numOfSuppliersNUD.Value - supplierCount;
            AddSuppliers(suppliers, numberToAdd);
            //GenerateConnections();
            supplierCount = (int)numOfSuppliersNUD.Value;

            

        }

        /// <summary>
        /// when the numeric up down changes on the suppliers add the new customers and re generate the connections.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void numOfCustomersNUD_ValueChanged(object sender, EventArgs e)
        {
            int numberToAdd = (int)numOfCustomersNUD.Value - customerCount;
            AddCustomers(customers,numberToAdd);
            //GenerateConnections();
            customerCount = (int)numOfCustomersNUD.Value;
        }

        private void minNUD_ValueChanged(object sender, EventArgs e)
        {
            min = (int)minNUD.Value;
            dataChart.ChartAreas.FindByName("ChartArea1").AxisX.Minimum = min;
            dataChart.ChartAreas.FindByName("ChartArea1").AxisY.Minimum = min;
        }

        private void maxNUD_ValueChanged(object sender, EventArgs e)
        {
            max = (int)maxNUD.Value;
            dataChart.ChartAreas.FindByName("ChartArea1").AxisX.Maximum = max;
            dataChart.ChartAreas.FindByName("ChartArea1").AxisY.Maximum = max;
        }








        private void suppliersAddRB_CheckedChanged(object sender, EventArgs e)
        {
            SwitchButtonValue();
        }




        private void suppliersSubtractRB_CheckedChanged(object sender, EventArgs e)
        {
            SwitchButtonValue();
        }

        private void customersAddRB_CheckedChanged(object sender, EventArgs e)
        {
            SwitchButtonValue();
        }

        private void customersSubtractRB_CheckedChanged(object sender, EventArgs e)
        {
            SwitchButtonValue();
        }


        /// <summary>
        /// a method to switch the text values of the buttons from + to - or - to + based on which radio buttons are checked 
        /// </summary>
        private void SwitchButtonValue()
        {
            if (suppliersAddRB.Checked)
            {
                supplierChangeByTenBTN.Text = "+ 10";
                supplierChangeByOneHundredBTN.Text = "+ 100";
                supplierChangeByOneThousandBTN.Text = "+ 1000";
            }
            else if (suppliersSubtractRB.Checked)
            {
                supplierChangeByTenBTN.Text = "- 10";
                supplierChangeByOneHundredBTN.Text = "- 100";
                supplierChangeByOneThousandBTN.Text = "- 1000";
            }
            if (customersAddRB.Checked)
            {
                customerChangeByTenBTN.Text = "+ 10";
                customerChangeByOneHundredBTN.Text = "+ 100";
                customerChangeByOneThousandBTN.Text = "+ 1000";
            }
            else if (customersSubtractRB.Checked)
            {
                customerChangeByTenBTN.Text = "- 10";
                customerChangeByOneHundredBTN.Text = "- 100";
                customerChangeByOneThousandBTN.Text = "- 1000";
            }
        }


        /// <summary>
        /// a method that parses the text values of the buttons and adds that value to the numeric up down 
        /// </summary>
        /// <param name="button"></param>
        public void AddValueToNumericUpDown(Button button)
        {
            string[] exploded = button.Text.Split(' ');
            int buttonValue = int.Parse(exploded[1]);
            if (customersGB.Contains(button) && customersAddRB.Checked == true)
            {
                
                numOfCustomersNUD.Value += buttonValue;
                Debug.WriteLine(customerCount);
                
            }
            else if(customersGB.Contains(button) && customersSubtractRB.Checked == true)
            {
                if (numOfCustomersNUD.Value - buttonValue > 0)
                {
                    numOfCustomersNUD.Value -= buttonValue;
                }
                else if(numOfCustomersNUD.Value - buttonValue <= 0)
                {
                    numOfCustomersNUD.Value = 0;
                }
                    
                Debug.WriteLine(exploded[1]);
            }

            else if (suppliersGB.Contains(button) && suppliersAddRB.Checked == true)
            {
                numOfSuppliersNUD.Value += buttonValue;
                Debug.WriteLine(exploded[1]);
            }
            else if (suppliersGB.Contains(button) && suppliersSubtractRB.Checked == true)
            {
                if (numOfSuppliersNUD.Value - buttonValue > 0)
                {
                    numOfSuppliersNUD.Value -= buttonValue;
                }
                else if (numOfSuppliersNUD.Value - buttonValue <= 0)
                {
                    numOfSuppliersNUD.Value = 0;
                }
                Debug.WriteLine(exploded[1]);
            }

        }
        private void supplierChangeByTenBTN_Click(object sender, EventArgs e)
        {
            AddValueToNumericUpDown(supplierChangeByTenBTN);
            
        }

        private void supplierChangeByOneHundredBTN_Click(object sender, EventArgs e)
        {
            AddValueToNumericUpDown(supplierChangeByOneHundredBTN);
            
        }

        private void supplierChangeByOneThousandBTN_Click(object sender, EventArgs e)
        {
            AddValueToNumericUpDown(supplierChangeByOneThousandBTN);
            
        }

        private void customerChangeByTenBTN_Click(object sender, EventArgs e)
        {
            AddValueToNumericUpDown(customerChangeByTenBTN);
            
        }

        private void customerChangeByOneHundredBTN_Click(object sender, EventArgs e)
        {
            AddValueToNumericUpDown(customerChangeByOneHundredBTN);
            
        }

        private void customerChangeByOneThousandBTN_Click(object sender, EventArgs e)
        {
            AddValueToNumericUpDown(customerChangeByOneThousandBTN);
            
        }

        private void maxNUD_Enter(object sender, EventArgs e)
        {
            max = (int)maxNUD.Value;
            dataChart.ChartAreas.FindByName("ChartArea1").AxisX.Maximum = max;
            dataChart.ChartAreas.FindByName("ChartArea1").AxisY.Maximum = max;
        }

        private void maxNUD_Leave(object sender, EventArgs e)
        {
            max = (int)maxNUD.Value;
            dataChart.ChartAreas.FindByName("ChartArea1").AxisX.Maximum = max;
            dataChart.ChartAreas.FindByName("ChartArea1").AxisY.Maximum = max;
        }

        private void minNUD_Enter(object sender, EventArgs e)
        {
            min = (int)minNUD.Value;
            dataChart.ChartAreas.FindByName("ChartArea1").AxisX.Minimum = min;
            dataChart.ChartAreas.FindByName("ChartArea1").AxisY.Minimum = min;
        }



        private void minNUD_Leave(object sender, EventArgs e)
        {
            min = (int)minNUD.Value;
            dataChart.ChartAreas.FindByName("ChartArea1").AxisX.Minimum = min;
            dataChart.ChartAreas.FindByName("ChartArea1").AxisY.Minimum = min;
        }


    }
}
